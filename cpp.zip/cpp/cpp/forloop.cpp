#include <iostream>
using namespace std;

int main () {

  int i, j = 0;

  for (;;) {

    cout << i << " " << j;
    i ++;
    j ++;

  }

  return 0;

}
